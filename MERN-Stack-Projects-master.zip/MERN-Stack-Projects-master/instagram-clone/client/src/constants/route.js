

export const API_URL = 'http://localhost:8000';

export const routePath = {
    home        : '/',
    profile     : '/profile'
}