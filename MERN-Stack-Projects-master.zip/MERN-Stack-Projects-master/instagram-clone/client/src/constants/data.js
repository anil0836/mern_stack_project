
export const instagramlLogo = 'https://www.instagram.com/static/images/web/logged_out_wordmark.png/7a252de00b20.png';
export const displayPhone = 'https://www.instagram.com/static/images/homepage/phones/home-phones.png/1dc085cdb87d.png'
export const applestore = 'https://www.instagram.com/static/images/appstore-install-badges/badge_ios_english-en.png/180ae7a0bcf7.png';
export const googlestore = 'https://www.instagram.com/static/images/appstore-install-badges/badge_android_english-en.png/e9cd846dc748.png';


export const loginImages = [
    'https://www.instagram.com/static/images/homepage/screenshots/screenshot2-2x.png/80b8aebdea57.png',
    'https://www.instagram.com/static/images/homepage/screenshots/screenshot1-2x.png/cfd999368de3.png',
    'https://www.instagram.com/static/images/homepage/screenshots/screenshot3-2x.png/fe2540684ab2.png',
    'https://www.instagram.com/static/images/homepage/screenshots/screenshot4-2x.png/8e9224a71939.png'
];

export const instagramLogo = 'https://www.instagram.com/static/images/web/logged_out_wordmark.png/7a252de00b20.png';
export const emptyprofilePicture = 'https://www.oseyo.co.uk/wp-content/uploads/2020/05/empty-profile-picture-png-2-2.png';
    
    